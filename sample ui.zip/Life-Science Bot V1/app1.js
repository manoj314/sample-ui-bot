var restify = require('restify');
var builder = require('botbuilder');
var servicenow=require('servicenow-rest-api');
var count;
var acsid = 'cera.damen';
var authtok = 'cera.damen';
var request = require("request");
var luis = require('./luis');
var auth = "Basic " + new Buffer(acsid + ":" + authtok).toString("base64");
var server = restify.createServer();
server.listen(process.env.port || process.env.PORT || 6400, function () {
    console.log('%s listening to %s', server.name, server.url);
});
var connector = new builder.ChatConnector({
    appId: "",
    appPassword: ""
});
var bot = new builder.UniversalBot(connector);
bot.on('conversationUpdate', (message) => {
    for (var i in message.membersAdded) {
        if (message.membersAdded[i].name == 'Bot') {
            //   var hello = new builder.Message()
            //   .address(message.address)
            //   .text(`Hi ${uname}, I am CERA your digital assistant.`);
            //   bot.send(hello);
            bot.beginDialog(message.address, '*:GreetingDialog');
        }

    }
});
// Register in-memory state storage
bot.set('storage', new builder.MemoryBotStorage());

//listen to incoming messages to bot
server.post('/api/messages', connector.listen());

// Add a dialog for each intent that the LUIS app recognizes.
// See https://docs.microsoft.com/en-us/bot-framework/nodejs/bot-builder-nodejs-recognize-intent-luis 

bot.dialog('/', [
    function (session) {
        var userquery = session.message.text;
        luis.identifyIntent(userquery).then(function (result) {

            console.log("LUIS Data: ", result)

            var data = JSON.parse(result);

            var intent = data.topScoringIntent.intent;
            var entities = data.entities;


            session.conversationData.intent = intent;
            session.conversationData.entities = entities

            switch (intent) {
                case 'Greeting': session.replaceDialog('GreetingDialog');
                    break;
                case 'Status': session.replaceDialog('Status');
                    break;
                case 'IncidentNumber': session.replaceDialog('IncidentNumber');
                    break;
                default: session.send("For assistance, you can type phrases like ticket status, I want to check my ticket");
                    session.endDialog();
                    break;
            }
        }).catch(function (err) {

            session.send("Sorry!!! I am facing trouble to answer your query, please try again later!!!");
            session.endDialog();
            console.log("Error: ", err);
        })

    }
]);

bot.dialog('GreetingDialog',
    (session) => {
        count = 0;
       // session.send('Hello Cera, Welcome to Damen Shipyards. My name is Blue, I am your virtual assistant. How May I help you? ');
       session.send('Hello Cera, Welcome to Damen Shipyards. My name is Blue, I am your virtual assistant. ');
       session.send('For assistance, you can type phrases like '+'ticket status, '+'I want to check my ticket');
        session.endDialog();

    }

).triggerAction({
    matches: 'Greeting'
})

bot.dialog('Issue',
    (session) => {
        session.send('You reached the Help intent. You said \'%s\'.', session.message.text);
        session.endDialog();
    }
)

bot.dialog('Status', [
    (session) => {
        var opt = '';
        var auth = "Basic " + new Buffer(acsid + ":" + authtok).toString("base64");
        var headers = {
            'Authorization': auth
        };session.send('Sure, I can help you with this. Kindly select from the below list of Incidents opened by you');
        request.get({
            headers: headers,
            url: 'https://tcsedev.service-now.com/api/now/table/incident?sysparm_query=sys_created_by%3Dcera.damen',
            //(https://tcsedev.service-now.com/api/now/table/incident?sysparm_query=number%3D%27+ticketno)
            'json': true

        }, function (error, response, body) {
               var a=[];
                for (var index = 0; index <= 4; index++) {
                    a.push(body.result[index].number);
                }
        
                builder.Prompts.choice(session,'Incident Numbers are', a[0]+'|'+a[1]+'|'+a[2]+'|'+a[3]+'|'+a[4]+'|'+'My incident is not listed here', { listStyle: 3 });
                console.log("body" + body.result);
            });
        // session.endDialog();
  
    },
    (session, results) => {
        var response = results.response.entity;
        if(response=='My incident is not listed here')
        {
            builder.Prompts.text(session,'Please enter your incident number');
        }
        else
        {
        session.userData.number = response;
        console.log("Number 1" + response);
        session.beginDialog('IncidentNumber');
        }
    },(session,results)=>
    {
        console.log("hwqejhqwe");
        var response = results.response; 
        session.userData.number = response;
        console.log("Number 2" + response);
        session.beginDialog('IncidentNumber');
    }
]
    // (session, results) => {
    //     var incidentNumber = results.response;
    //     session.userData.selectedHotel = hotel;
    //     builder.Prompts.choice(session, ' Are you sure with the booking?', 'yes|no', { listStyle: 3 });
    // }
)

bot.dialog('IncidentNumber', [
    (session) => {
        // var INCNum;

        // entities = session.conversationData.entities;
        // // console.log(entities.length);
        // // console.log(entities[0].type);
        // // console.log(entities[1].type);

        // entities.forEach(function (member) {
        //     // console.log(entities[i].type);
        //     if (member.type == "INCNumber") {
        //         console.log("abc");
        //         INCNum = member.entity;
        //         console.log(member.entity);
        //         session.userData.inc = INCNum;
        //         console.log(INCNum);
        //     }
        // });
        var number = session.userData.number;
        console.log("Incident Number "+number);
        var headers = {
            'Authorization': auth
        };

        request.get({
            headers: headers,
            url: 'https://tcsedev.service-now.com/api/now/table/incident?sysparm_query=number%3D' + number,
            //(https://tcsedev.service-now.com/api/now/table/incident?sysparm_query=number%3D%27+ticketno)
            'json': true

        }, function (error, response, body) {

            console.log("JSON"+JSON.stringify(body));
            if (body.result[0]) {
                var sysId=body.result[0].sys_id;
                console.log("Sys"+sysId);
                session.userData.sysId=sysId;
                session.send("Here are the Incident Details. \n  Incident Number: " + body.result[0].number + " \n Short Description: " + body.result[0].short_description +"\n Priority: "+body.result[0].priority+ "\n Category: " + body.result[0].category + "\n Sub-category: " + body.result[0].subcategory);
                //builder.Prompts.confirm(session, "Kindly select from the following for more options");
                //session.send("Kindly select from the following for more options");
                builder.Prompts.choice(session,'You can select from the following for more options', 'Get another incident status'+'|'+'Update this incident'+'|'+'Exit', { listStyle: 3 });
            }
            else {
                if (count > 1) {
                    // session.endDialog("Try again");
                    session.beginDialog("Status");               
                }
                else {
                   // count++;
                    //session.send("Unfortunately, " + session.userData.number + " does not exist. Could you please provide the Incident number again?");
                    session.beginDialog('test');
                }
            }
        });
    }, (session, results) => {
        var response=results.response.entity;
        console.log("Response :"+response);
      if(count<2){
        switch (response) {
            case 'Get another incident status': session.replaceDialog('Status');
                break;
            case 'Update this incident': session.replaceDialog('update');
                break;
            case 'Exit': session.send("Have a great day. I am just a Click away!");
            session.endDialog();
                break;
            default: session.send("Please rephrase your Query");
                session.endDialog();
                break;
        }
      }  
      else{
         

      }
        // if (results.response) {
        //     console.log("qwerty")
        //     session.beginDialog('GreetingDialog');
        // }
        // else {
        //     session.endDialog('Have a great day. I am just a Click away!');
        // }
    }]

);

    bot.dialog('test',[
    (session)=>{
    builder.Prompts.text(session,"Unfortunately, " + session.userData.number + " does not exist. Could you please provide the Incident number again?");
    count++;
    },(session,results)=>
    {
        var response=results.response;
        session.userData.number=response;
        session.beginDialog('IncidentNumber');
    }
])
    bot.dialog('update',[
    (session)=>
    {
        builder.Prompts.choice(session,'Kindly select from the following which field you want to update', 'Comments'+'|'+'Priority', { listStyle: 3 });
    },(session,results)=>
    {
        var response=results.response.entity;
        console.log("Response"+response);
        switch (response) {
            case 'Comments': session.replaceDialog('Comments');
                break;
            case 'Priority': session.replaceDialog('Priority');
                break;
            default: session.beginDialog('update'); //session.send("Please rephrase your Query");
                break;
        }
    }]
    );


    bot.dialog('Comments',[
        (session)=>{
            builder.Prompts.text(session,'Please provide the comments');
            console.log('comments');
        },
        (session,results) => {
             var response=results.response;
             var incidentNumber=session.userData.number;
             console.log('comments'+response);
             //var auth = "Basic " + new Buffer(acsid + ":" + authtok).toString("base64");
            // var headers = {
              //  'Authorization': 'Basic '+new Buffer('admin' + ':' + 'Service@123').toString('base64')
            //};
            const ServiceNow=new servicenow('tcsedev',acsid,authtok);
            ServiceNow.Authenticate();
    
            const data={
                'comments':response
                // 'work_notes':'Assigning this to different team',
                // 'assignment_group':'Network'
            };
            console.log('data  '+JSON.stringify(data));
            ServiceNow.UpdateTask('incident',incidentNumber,data,res=>{
                console.log(res);
            });
    
            session.send('Comment has been added to this Incident');
            session.beginDialog('editor');
            // request.patch({
            //     headers: headers,
            //     'url': 'https://dev61329.service-now.com/api/now/table/incident/' +sysId,
            //     'body':update,
            //     'json': true
    
            // },function (error, response, body) {
            //     console.log(JSON.stringify(body));
            //     console.log(JSON.stringify(response));
            // });
        }]
     );

    // bot.dialog('WorkNotes',
    // (session)=>
    // {

    // }
    // )

    bot.dialog('Priority',[
    (session)=>
    {
        session.send('Priority can be changed as per the following available options');
        builder.Prompts.choice(session,'Please select the priority level', 'P3-Medium'+'|'+'P2-High'+'|'+'P1-Critical', { listStyle: 3 });
    },
    (session,results)=>
    {
        var response=results.response.entity;
        console.log("Response"+response);
        switch (response) {
            case 'P3-Medium': session.replaceDialog('medium');
                break;
            case 'P2-High': session.replaceDialog('high');
                break;
            case 'P1-Critical': session.replaceDialog('critical');
                break;
            default: session.send("Please rephrase your Query");
                session.endDialog();
                break;
        }
    }]
    );

    bot.dialog('critical',
    (session)=>
    {
            session.send('Priority cannot be escalated directly to P1-Critical. Please contact ServiceDesk for further support');
            builder.Prompts.choice(session,'Kindly select from the following for more options', 'Get another incident status'+'|'+'Update this incident'+'|'+'Exit', { listStyle: 3 }); 
    }, (session,results)=>
    {
            var response=results.response.entity;
            console.log("Response in critical:"+response);
            switch (response) {
                case 'Get another incident status': session.replaceDialog('Status');
                    break;
                case 'Update this incident': session.replaceDialog('update');
                    break;
                case 'Exit': session.send("Have a great day. I am just a Click away!");
                session.endDialog();
                    break;
                default: session.send("Please rephrase your Query");
                    session.endDialog();
                    break;
            }
    }
    );




bot.dialog('medium',
       
     (session) => {
         //var response=results.response.entity;
         var sysId=session.userData.sysId;
         var incidentNumber=session.userData.number;
         console.log('medium'+incidentNumber);
         var update={
             'impact':2
         };
         //var auth = "Basic " + new Buffer(acsid + ":" + authtok).toString("base64");
         var headers = {
            'Authorization': 'Basic '+new Buffer('admin' + ':' + 'Service@123').toString('base64')
        };
        const ServiceNow=new servicenow('tcsedev',acsid,authtok);
        ServiceNow.Authenticate();

        const data={
            'impact':'1'
            // 'work_notes':'Assigning this to different team',
            // 'assignment_group':'Network'
        };
        
        ServiceNow.UpdateTask('incident',incidentNumber,data,res=>{
            console.log(res);
        });

        session.send('Priority for the Incident has been updated');
        session.beginDialog('editor');
        // request.patch({
        //     headers: headers,
        //     'url': 'https://dev61329.service-now.com/api/now/table/incident/' +sysId,
        //     'body':update,
        //     'json': true

        // },function (error, response, body) {
        //     console.log(JSON.stringify(body));
        //     console.log(JSON.stringify(response));
        // });
    }
 )

 bot.dialog('high',[
    (session)=>{
        builder.Prompts.text(session,'Please provide reason for elevating the priority to P2-High');
        console.log('High priority');
    },
    (session,results) => {
        console.log('bemby');
         var sysId=session.userData.sysId;
         var response=results.response;
         var incidentNumber=session.userData.number;
         console.log('high'+incidentNumber);
         console.log('high 1'+response);
         //var auth = "Basic " + new Buffer(acsid + ":" + authtok).toString("base64");
        // var headers = {
          //  'Authorization': 'Basic '+new Buffer('admin' + ':' + 'Service@123').toString('base64')
        //};
        const ServiceNow=new servicenow('tcsedev',acsid,authtok);
        ServiceNow.Authenticate();

        const data={
            'comments':response,
            'impact':'1',
            'urgency':'2'
            // 'work_notes':'Assigning this to different team',
            // 'assignment_group':'Network'
        };
        console.log('data  '+JSON.stringify(data));
        ServiceNow.UpdateTask('incident',incidentNumber,data,res=>{
            console.log(res);
        });

        session.send('Priority for the Incident has been updated');
        session.beginDialog('editor');
        // request.patch({
        //     headers: headers,
        //     'url': 'https://dev61329.service-now.com/api/now/table/incident/' +sysId,
        //     'body':update,
        //     'json': true

        // },function (error, response, body) {
        //     console.log(JSON.stringify(body));
        //     console.log(JSON.stringify(response));
        // });
    }]
 );

    // bot.dialog('update',
    // (session)
    // )

bot.dialog('editor',[
    (session) => {
        builder.Prompts.choice(session,'You can select from the following for more options', 'Get another incident status'+'|'+'Update this incident'+'|'+'Exit', { listStyle: 3 });
    },(session, results) => {
        var response=results.response.entity;
        console.log("Response :"+response);
        switch (response) {
            case 'Get another incident status': session.replaceDialog('Status');
                break;
            case 'Update this incident': session.replaceDialog('update');
                break;
            case 'Exit': session.send("Have a great day. I am just a Click away!");
            session.endDialog();
                break;
            default: session.send("Please rephrase your Query");
                session.endDialog();
                break;
        }
        // if (results.response) {
        //     console.log("qwerty")
        //     session.beginDialog('GreetingDialog');
        // }
        // else {
        //     session.endDialog('Have a great day. I am just a Click away!');
        // }
    }]
)
// bot.dialog('CancelDialog',
//     (session) => {
//         session.send('You reached the Cancel intent. You said \'%s\'.', session.message.text);
//         session.endDialog();
//     }
// )
