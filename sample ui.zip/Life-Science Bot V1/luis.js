var request = require("request");

var luisApi = "https://westeurope.api.cognitive.microsoft.com/luis/v2.0/apps/e71e84da-97cd-49c4-8319-bef5fdf3dda9?verbose=true&timezoneOffset=60&subscription-key=9d580bf381b24aa9b0e12050062b78d3&q="

module.exports = {
    identifyIntent(query) {
        return new Promise((resolve, reject) => {
            request(luisApi + query, function (error, response, body) {
                if (error) {
                    reject(error);
                }
                else {
                    resolve(body);
                }
            })
        })
    }
}